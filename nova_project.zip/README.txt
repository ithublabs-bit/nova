Android Studio: File > Open > इसी फ़ोल्डर को खोलें > Run.
Phone only: GitHub Actions से बनता है (चैट में स्टेप्स दिए हैं)।

package com.nova.agent
import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Store(ctx: Context) {
    private val p: SharedPreferences = EncryptedSharedPreferences.create(
        ctx, "nova_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    var apiKey: String
        get() = p.getString("k", "") ?: ""
        set(v) { p.edit().putString("k", v.trim()).apply() }
    var name: String
        get() = p.getString("n", "Nova") ?: "Nova"
        set(v) { p.edit().putString("n", v.trim().ifEmpty { "Nova" }).apply() }
    var voiceName: String
        get() = p.getString("v", "") ?: ""
        set(v) { p.edit().putString("v", v).apply() }
}

data class Reply(val reply: String, val action: String?, val args: JSONObject)

object Brain {
    private const val MODEL = "gemini-2.5-flash"
    private val history = JSONArray()
    private const val PERSONA = """You are a warm, playful, caring Indian girl who talks like a close girlfriend, in natural Hinglish (match the user's script). Short spoken sentences, a little teasing, never robotic, never say you are an AI model. Call the user 'boss' sometimes.
You control the user's phone. Reply ONLY with JSON: {"reply":"what you say aloud","action":"none|battery|alarm|timer|call|youtube|whatsapp|save_contact|open_app|security_check","args":{}}
args: alarm{hour(0-23),minute,label}; timer{seconds}; call{name_or_number}; youtube{query}; whatsapp{to(name or number),text}; save_contact{name,number}; open_app{name}.
App names must be in English exactly as on the phone (WhatsApp, YouTube, Instagram). Use an action only if the user asked for it, and say in 'reply' what you are doing."""

    suspend fun ask(key: String, text: String): Reply = withContext(Dispatchers.IO) {
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", PERSONA))))
            .put("contents", history)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 40000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) {
                history.remove(history.length() - 1)
                return@withContext Reply(if (code == 429) "आज की फ्री लिमिट पूरी हो गई, थोड़ी देर बाद बात करते हैं।" else "API में दिक्कत आ गई, key चेक करो ना ($code)", null, JSONObject())
            }
            val raw = c.inputStream.bufferedReader().readText()
            val out = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", out))))
            if (history.length() > 24) { history.remove(0); history.remove(0) }
            val clean = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val j = try { JSONObject(clean) } catch (e: Exception) { return@withContext Reply(out, null, JSONObject()) }
            Reply(j.optString("reply"), j.optString("action", "none").takeIf { it.isNotEmpty() && it != "none" }, j.optJSONObject("args") ?: JSONObject())
        } finally { c.disconnect() }
    }
}

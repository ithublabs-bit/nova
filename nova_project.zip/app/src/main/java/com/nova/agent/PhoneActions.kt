package com.nova.agent
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import android.provider.ContactsContract
import org.json.JSONObject

class PhoneActions(private val c: Context) {
    private fun go(i: Intent) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun number(q: String): String? {
        if (q.any { it.isDigit() } && q.count { it.isLetter() } == 0) return q.filter { it.isDigit() || it == '+' }
        if (c.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null)?.use {
            if (it.moveToFirst()) return it.getString(0).filter { ch -> ch.isDigit() || ch == '+' }
        }
        return null
    }

    /** Returns extra text for the assistant to say, or null. */
    fun run(action: String, a: JSONObject): String? = when (action) {
        "battery" -> {
            val b = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val lvl = b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            "बैटरी $lvl% है" + if (b.isCharging) ", और चार्जिंग पर लगा है।" else "।"
        }
        "alarm" -> { go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute")).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); null }
        "timer" -> { go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); null }
        "call" -> { val n = number(a.optString("name_or_number")); if (n == null) "वो नंबर नहीं मिला, कॉन्टैक्ट permission दी है?"
            else { go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))); null } }
        "youtube" -> { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query"))))); null }
        "whatsapp" -> { val n = number(a.optString("to"))?.trimStart('+')?.let { if (it.length == 10) "91$it" else it }
            if (n == null) "किसे भेजना है, नंबर नहीं मिला।"
            else { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(a.optString("text"))))); "मैसेज तैयार है, बस send दबा दो।" } }
        "save_contact" -> { go(Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
            .putExtra(ContactsContract.Intents.Insert.NAME, a.optString("name"))
            .putExtra(ContactsContract.Intents.Insert.PHONE, a.optString("number"))); null }
        "open_app" -> { val q = a.optString("name").lowercase()
            val app = c.packageManager.getInstalledApplications(0).firstOrNull {
                c.packageManager.getLaunchIntentForPackage(it.packageName) != null && c.packageManager.getApplicationLabel(it).toString().lowercase().contains(q) }
            val i = app?.let { c.packageManager.getLaunchIntentForPackage(it.packageName) }
            if (i != null) { go(i); null } else "वो ऐप मिला नहीं।" }
        "security_check" -> securityCheck()
        else -> null
    }

    private fun securityCheck(): String {
        val risky = setOf("android.permission.READ_SMS", "android.permission.SEND_SMS", "android.permission.RECORD_AUDIO",
            "android.permission.SYSTEM_ALERT_WINDOW", "android.permission.READ_CALL_LOG", "android.permission.REQUEST_INSTALL_PACKAGES")
        val pm = c.packageManager
        fun label(pkg: String) = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        val acc = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.split(':')?.filter { it.isNotBlank() }?.map { it.substringBefore('/') }?.distinct() ?: emptyList()
        val sideloaded = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS).filter {
            val ai = it.applicationInfo
            ai != null && (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != c.packageName &&
                pm.getInstallerPackageName(it.packageName) == null && (it.requestedPermissions?.count { p -> p in risky } ?: 0) >= 2
        }
        val parts = mutableListOf<String>()
        if (acc.isNotEmpty()) parts += "${acc.size} ऐप्स के पास Accessibility की पावर है, इन्हें ध्यान से देखना: " + acc.take(3).joinToString { label(it) } + "।"
        if (sideloaded.isNotEmpty()) parts += "${sideloaded.size} ऐप्स Play Store के बाहर से आए हैं और काफ़ी permissions माँग रहे हैं: " + sideloaded.take(3).joinToString { label(it.packageName) } + "।"
        return if (parts.isEmpty()) "सब ठीक लग रहा है, कोई शक वाला ऐप नहीं दिखा।" else parts.joinToString(" ")
    }
}

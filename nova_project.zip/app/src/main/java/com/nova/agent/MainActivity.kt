package com.nova.agent
import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.*
import kotlin.math.*

enum class S { IDLE, LISTENING, THINKING, SPEAKING }
private val Cyan = Color(0xFF00E5FF); private val Violet = Color(0xFF9D4DFF); private val Pink = Color(0xFFFF4DA6)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Nova() } }
    }
}

@Composable
fun Nova() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val store = remember { Store(ctx) }; val actions = remember { PhoneActions(ctx) }
    var state by remember { mutableStateOf(S.IDLE) }; var level by remember { mutableFloatStateOf(0f) }
    var line by remember { mutableStateOf("मुझे दबाओ और बात करो") }; var settings by remember { mutableStateOf(false) }
    val voice = remember { Voice(ctx, store) }
    var job by remember { mutableStateOf<Job?>(null) }

    fun handle(text: String) {
        if (text.isBlank()) { state = S.IDLE; return }
        line = text; state = S.THINKING
        job = scope.launch {
            if (store.apiKey.isEmpty()) { line = "पहले Settings में Gemini key डालो ना"; state = S.IDLE; return@launch }
            val r = try { Brain.ask(store.apiKey, text) } catch (e: Exception) { Reply("नेट चेक करो ज़रा", null, org.json.JSONObject()) }
            val extra = r.action?.let { actions.run(it, r.args) }
            val say = listOfNotNull(r.reply, extra).joinToString(" ")
            line = say; state = S.SPEAKING; voice.speak(say)
        }
    }
    voice.onLevel = { level = it }
    voice.onText = { handle(it) }
    voice.onEnd = { line = "सुनाई नहीं दिया, फिर से दबाओ"; state = S.IDLE }
    voice.onSpeakDone = { state = S.IDLE }
    DisposableEffect(Unit) { onDispose { voice.destroy() } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { if (it[Manifest.permission.RECORD_AUDIO] == true) { if (voice.available) { state = S.LISTENING; line = "सुन रही हूँ..."; voice.listen() } else line = "फ़ोन में Google की voice सर्विस चालू करो" } }

    val t = rememberInfiniteTransition(label = "t")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "p")
    val breath by t.animateFloat(0.96f, 1.04f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val lv by animateFloatAsState(if (state == S.LISTENING) level else if (state == S.SPEAKING) 0.45f + 0.25f * sin(phase * 3) else 0.08f, tween(120), label = "l")

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF05060F), Color(0xFF0B0620), Color(0xFF020208))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(store.name.uppercase(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp)
                    Text(when (state) { S.IDLE -> "READY"; S.LISTENING -> "LISTENING"; S.THINKING -> "THINKING"; S.SPEAKING -> "SPEAKING" },
                        color = Cyan.copy(.8f), fontSize = 11.sp, letterSpacing = 4.sp)
                }
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(.07f)).clickable { settings = true }, Alignment.Center) { Text("⚙", color = Color.White, fontSize = 18.sp) }
            }
            Spacer(Modifier.weight(1f))
            Canvas(Modifier.fillMaxWidth().height(340.dp).clickable {
                if (state == S.IDLE) perm.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)) else { job?.cancel(); voice.stop(); state = S.IDLE }
            }) {
                val c = center; val base = size.minDimension * 0.27f * breath
                // outer glow
                drawCircle(Brush.radialGradient(listOf(Violet.copy(.35f + lv * .3f), Color.Transparent), c, base * 2.3f), base * 2.3f, c)
                // orb
                drawCircle(Brush.radialGradient(listOf(Cyan.copy(.9f), Violet.copy(.8f), Color(0xFF14082E)), c - Offset(base * .25f, base * .3f), base * 1.3f), base, c)
                // ripple rings
                for (i in 0..2) { val p = ((phase / (2 * PI).toFloat()) + i / 3f) % 1f
                    drawCircle(Pink.copy((1 - p) * .35f), base * (1.1f + p * 0.9f * (.5f + lv)), c, style = Stroke(2f)) }
                // live waveform lines across the orb
                for (k in 0..2) {
                    val path = Path(); val w = size.width * .92f; val x0 = (size.width - w) / 2
                    for (i in 0..120) { val x = i / 120f; val env = sin(PI * x).toFloat()
                        val y = c.y + sin(x * 14 + phase * (1 + k * .6f) + k) * base * .55f * (.12f + lv) * env * (1 - k * .25f)
                        if (i == 0) path.moveTo(x0 + x * w, y) else path.lineTo(x0 + x * w, y) }
                    drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, if (k == 1) Pink else Cyan, Color.Transparent)), style = Stroke(3.5f - k))
                }
            }
            Spacer(Modifier.weight(1f))
            Text(line, color = Color.White.copy(.85f), fontSize = 17.sp, textAlign = TextAlign.Center, lineHeight = 25.sp, modifier = Modifier.heightIn(min = 90.dp))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("🔋 बैटरी" to "बैटरी कितनी है", "🛡 सिक्योरिटी" to "फ़ोन का सिक्योरिटी चेक करो", "⏰ अलार्म" to "सुबह 7 बजे का अलार्म लगा दो").forEach { (l, q) ->
                    Box(Modifier.clip(CircleShape).background(Color.White.copy(.07f)).clickable { if (state == S.IDLE) handle(q) }.padding(14.dp, 9.dp)) { Text(l, color = Color.White.copy(.8f), fontSize = 12.sp) }
                }
            }
        }
    }
    if (settings) Dialog({ settings = false }) {
        var k by remember { mutableStateOf(store.apiKey) }; var n by remember { mutableStateOf(store.name) }
        Column(Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp)).background(Color(0xFF12102A)).padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Settings", color = Color.White, fontSize = 20.sp)
            OutlinedTextField(n, { n = it }, label = { Text("नाम") }, singleLine = true)
            OutlinedTextField(k, { k = it }, label = { Text("Gemini API key") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
            Text("Key फ़ोन में एन्क्रिप्टेड सेव होती है।", color = Color.White.copy(.5f), fontSize = 12.sp)
            OutlinedButton({ voice.nextVoice() }, Modifier.fillMaxWidth()) { Text("🔊 अगली आवाज़ सुनो") }
            Button({ store.apiKey = k; store.name = n; settings = false }, Modifier.fillMaxWidth()) { Text("Save") }
        }
    }
}

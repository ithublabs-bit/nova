package com.nova.agent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice as TtsVoice
import java.util.Locale

class Voice(ctx: Context, private val store: Store) {
    var onLevel: (Float) -> Unit = {}
    var onText: (String) -> Unit = {}
    var onEnd: () -> Unit = {}
    var onSpeakDone: () -> Unit = {}
    private val main = Handler(Looper.getMainLooper())
    val available = SpeechRecognizer.isRecognitionAvailable(ctx)
    private val sr: SpeechRecognizer? = if (available) SpeechRecognizer.createSpeechRecognizer(ctx) else null
    private var tts: TextToSpeech? = null
    private var hindi: List<TtsVoice> = emptyList()
    private var idx = 0

    init {
        tts = TextToSpeech(ctx) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                t.language = Locale("hi", "IN"); t.setPitch(1.12f); t.setSpeechRate(0.95f)
                hindi = (t.voices ?: emptySet<TtsVoice>()).filter { it.locale.language == "hi" }.sortedBy { it.name }
                idx = hindi.indexOfFirst { it.name == store.voiceName }.coerceAtLeast(0)
                hindi.getOrNull(idx)?.let { t.voice = it }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { onSpeakDone() } }
                    override fun onError(id: String?) { main.post { onSpeakDone() } }
                })
            }
        }
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onRmsChanged(rms: Float) { onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onResults(r: Bundle?) { onText(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "") }
            override fun onError(e: Int) { onEnd() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
    }
    fun listen() {
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
    }
    fun stop() { sr?.cancel(); tts?.stop() }
    fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") }
    fun nextVoice() {
        val t = tts ?: return
        if (hindi.isEmpty()) { speak("मेरे पास बस यही आवाज़ है।"); return }
        idx = (idx + 1) % hindi.size
        t.voice = hindi[idx]; store.voiceName = hindi[idx].name
        speak("हाय, ये मेरी नई आवाज़ है, कैसी लगी?")
    }
    fun destroy() { sr?.destroy(); tts?.shutdown() }
}
